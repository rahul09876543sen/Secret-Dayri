
import React, { useEffect } from 'react';
import { Home, Calendar, Smile, Tag, Settings } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useThemeStore } from '@/store/themeStore';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

type NavItem = {
  icon: React.ElementType;
  path: string;
  label: string;
};

const navItems: NavItem[] = [
  { icon: Home, path: '/', label: 'Home' },
  { icon: Calendar, path: '/calendar', label: 'Calendar' },
  { icon: Smile, path: '/mood', label: 'Mood' },
  { icon: Tag, path: '/tags', label: 'Tags' },
  { icon: Settings, path: '/settings', label: 'Settings' },
];

interface LayoutProps {
  children: React.ReactNode;
  showFAB?: boolean;
}

const Layout: React.FC<LayoutProps> = ({ children, showFAB = true }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { theme } = useThemeStore();
  
  // Apply theme to document
  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="p-4 border-b bg-white dark:bg-gray-900 flex justify-center">
        <h1 className="text-2xl font-serif font-bold text-diary-purple">Sen Secret Diary</h1>
      </header>

      {/* Main content */}
      <main className="flex-1 py-6 px-4 overflow-y-auto">
        {children}
      </main>

      {/* Floating Action Button */}
      {showFAB && (
        <div className="fixed right-6 bottom-20 z-10">
          <Button 
            onClick={() => navigate('/new-entry')}
            className="h-14 w-14 rounded-full bg-diary-purple hover:bg-diary-dark-purple shadow-lg animate-float"
          >
            <span className="text-2xl font-bold">+</span>
          </Button>
        </div>
      )}

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t z-10">
        <div className="flex justify-between items-center">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            return (
              <button
                key={item.path}
                className={cn(
                  "flex flex-1 flex-col items-center py-3 px-2",
                  isActive 
                    ? "text-diary-purple dark:text-diary-light-purple" 
                    : "text-gray-500 dark:text-gray-400"
                )}
                onClick={() => navigate(item.path)}
              >
                <Icon size={20} />
                <span className="text-xs mt-1">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
};

export default Layout;
