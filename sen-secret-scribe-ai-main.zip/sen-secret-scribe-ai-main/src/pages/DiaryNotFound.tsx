
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import Layout from '@/components/Layout';

const DiaryNotFound: React.FC = () => {
  const navigate = useNavigate();
  
  return (
    <Layout showFAB={false}>
      <div className="max-w-md mx-auto text-center py-12">
        <h2 className="text-3xl font-serif font-bold mb-4">Page Not Found</h2>
        <p className="mb-8 text-diary-text-secondary">
          The diary page you're looking for doesn't exist or has been moved.
        </p>
        
        <Button 
          onClick={() => navigate('/')}
          className="bg-diary-purple hover:bg-diary-dark-purple"
        >
          Return to Diary Home
        </Button>
      </div>
    </Layout>
  );
};

export default DiaryNotFound;
