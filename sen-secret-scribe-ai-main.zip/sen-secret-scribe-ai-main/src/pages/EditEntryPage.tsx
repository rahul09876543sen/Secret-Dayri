
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDiaryStore, MoodType } from '@/store/diaryStore';
import Layout from '@/components/Layout';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

const moodOptions: { value: MoodType; label: string }[] = [
  { value: 'happy', label: 'Happy 😊' },
  { value: 'sad', label: 'Sad 😢' },
  { value: 'angry', label: 'Angry 😠' },
  { value: 'calm', label: 'Calm 😌' },
  { value: 'excited', label: 'Excited 😃' },
  { value: 'anxious', label: 'Anxious 😰' },
  { value: 'neutral', label: 'Neutral 😐' },
];

const EditEntryPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getEntry, updateEntry } = useDiaryStore();
  const { toast } = useToast();
  
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [mood, setMood] = useState<MoodType | undefined>(undefined);
  const [tags, setTags] = useState('');
  
  useEffect(() => {
    if (id) {
      const entry = getEntry(id);
      if (entry) {
        setTitle(entry.title);
        setContent(entry.content);
        setMood(entry.mood);
        setTags(entry.tags.join(', '));
      } else {
        toast({
          title: "Entry not found",
          description: "The diary entry you're trying to edit doesn't exist.",
          variant: "destructive",
        });
        navigate('/');
      }
    }
  }, [id, getEntry, navigate, toast]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!id) return;
    
    if (!title.trim() || !content.trim()) {
      toast({
        title: "Missing information",
        description: "Please add a title and content for your diary entry.",
        variant: "destructive",
      });
      return;
    }

    updateEntry(id, {
      title,
      content,
      mood,
      tags: tags.split(',').map(tag => tag.trim()).filter(Boolean),
    });
    
    toast({
      title: "Entry updated",
      description: "Your diary entry has been updated successfully.",
    });
    
    navigate(`/entry/${id}`);
  };

  return (
    <Layout showFAB={false}>
      <div className="max-w-2xl mx-auto">
        <h2 className="text-2xl font-serif font-bold mb-6">Edit Diary Entry</h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="title" className="block mb-2 font-medium">
              Title
            </label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Today's thoughts..."
              className="diary-input"
              required
            />
          </div>
          
          <div>
            <label htmlFor="content" className="block mb-2 font-medium">
              What's on your mind?
            </label>
            <Textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Write your thoughts here..."
              className="diary-input min-h-[200px]"
              required
            />
          </div>
          
          <div>
            <label className="block mb-2 font-medium">
              How are you feeling?
            </label>
            
            <div className="flex flex-wrap gap-2">
              {moodOptions.map((option) => (
                <Button
                  key={option.value}
                  type="button"
                  variant={mood === option.value ? "default" : "outline"}
                  size="sm"
                  className={mood === option.value ? "bg-diary-purple" : ""}
                  onClick={() => setMood(option.value)}
                >
                  {option.label}
                </Button>
              ))}
            </div>
          </div>
          
          <div>
            <label htmlFor="tags" className="block mb-2 font-medium">
              Tags (comma separated)
            </label>
            <Input
              id="tags"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="personal, reflection, goals"
              className="diary-input"
            />
          </div>
          
          <div className="flex justify-end space-x-4 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate(-1)}
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              className="bg-diary-purple hover:bg-diary-dark-purple"
            >
              Update Entry
            </Button>
          </div>
        </form>
      </div>
    </Layout>
  );
};

export default EditEntryPage;
