
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDiaryStore } from '@/store/diaryStore';
import Layout from '@/components/Layout';
import { format } from 'date-fns';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Edit, Trash2, ChevronLeft, Tag, Smile } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

const EntryDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getEntry, deleteEntry } = useDiaryStore();
  const [entry, setEntry] = useState(id ? getEntry(id) : undefined);
  const { toast } = useToast();
  
  useEffect(() => {
    if (id) {
      const foundEntry = getEntry(id);
      setEntry(foundEntry);
      
      if (!foundEntry) {
        toast({
          title: "Entry not found",
          description: "The diary entry you're looking for doesn't exist.",
          variant: "destructive",
        });
        navigate('/');
      }
    }
  }, [id, getEntry, navigate, toast]);
  
  if (!entry) {
    return null;
  }
  
  const formattedDate = format(new Date(entry.createdAt), 'MMMM d, yyyy h:mm a');
  
  const handleDelete = () => {
    if (id) {
      deleteEntry(id);
      toast({
        title: "Entry deleted",
        description: "Your diary entry has been deleted.",
      });
      navigate('/');
    }
  };

  return (
    <Layout showFAB={false}>
      <div className="max-w-2xl mx-auto animate-fade-in">
        {/* Back button and actions */}
        <div className="flex justify-between items-center mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate(-1)}
            className="flex items-center"
          >
            <ChevronLeft size={16} className="mr-1" />
            Back
          </Button>
          
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate(`/edit-entry/${entry.id}`)}
              className="flex items-center"
            >
              <Edit size={16} className="mr-1" />
              Edit
            </Button>
            
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="destructive"
                  size="sm"
                  className="flex items-center"
                >
                  <Trash2 size={16} className="mr-1" />
                  Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete Entry</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to delete this diary entry? This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
        
        {/* Entry content */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h1 className="text-3xl font-serif font-bold mb-2">{entry.title}</h1>
          <p className="text-sm text-diary-text-secondary mb-6">{formattedDate}</p>
          
          {/* Mood indicator */}
          {entry.mood && (
            <div className="flex items-center mb-4 text-diary-text-secondary">
              <Smile size={18} className="mr-2" />
              <span className="capitalize">{entry.mood}</span>
            </div>
          )}
          
          {/* Content */}
          <div className="diary-entry mb-8 whitespace-pre-wrap">
            {entry.content}
          </div>
          
          {/* Tags */}
          {entry.tags.length > 0 && (
            <div className="mt-6">
              <div className="flex items-center mb-2 text-diary-text-secondary">
                <Tag size={18} className="mr-2" />
                <span>Tags</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {entry.tags.map((tag) => (
                  <Badge key={tag} variant="secondary">{tag}</Badge>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default EntryDetailPage;
