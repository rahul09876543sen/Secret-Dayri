
import React, { useMemo } from 'react';
import Layout from '@/components/Layout';
import { useDiaryStore } from '@/store/diaryStore';
import { Card } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';

const TagsPage: React.FC = () => {
  const navigate = useNavigate();
  const { entries, getEntriesByTag } = useDiaryStore();
  
  // Extract unique tags and count entries for each
  const tags = useMemo(() => {
    const tagCount: Record<string, number> = {};
    
    entries.forEach(entry => {
      entry.tags.forEach(tag => {
        if (tagCount[tag]) {
          tagCount[tag] += 1;
        } else {
          tagCount[tag] = 1;
        }
      });
    });
    
    // Sort by count (descending)
    return Object.entries(tagCount)
      .sort((a, b) => b[1] - a[1])
      .map(([tag, count]) => ({ tag, count }));
  }, [entries]);
  
  const [selectedTag, setSelectedTag] = React.useState<string | null>(
    tags.length > 0 ? tags[0].tag : null
  );
  
  // Get entries for selected tag
  const entriesWithTag = useMemo(() => {
    if (!selectedTag) return [];
    return getEntriesByTag(selectedTag).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [selectedTag, getEntriesByTag]);
  
  if (tags.length === 0) {
    return (
      <Layout>
        <div className="max-w-2xl mx-auto">
          <h2 className="text-2xl font-serif font-bold mb-6">Tags</h2>
          
          <Card className="p-8 text-center">
            <p className="text-diary-text-secondary mb-4">
              No tags available yet. Start adding tags to your diary entries!
            </p>
            <button 
              className="text-diary-purple hover:underline"
              onClick={() => navigate('/new-entry')}
            >
              Create your first tagged entry
            </button>
          </Card>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout>
      <div className="max-w-2xl mx-auto">
        <h2 className="text-2xl font-serif font-bold mb-6">Tags</h2>
        
        <Card className="p-6 mb-6 diary-card">
          <h3 className="text-lg font-medium mb-4">Browse By Tag</h3>
          
          <div className="flex flex-wrap gap-2">
            {tags.map(({ tag, count }) => (
              <Badge
                key={tag}
                onClick={() => setSelectedTag(tag)}
                className={`cursor-pointer px-3 py-1 ${
                  selectedTag === tag
                    ? 'bg-diary-purple text-white hover:bg-diary-dark-purple'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200'
                }`}
              >
                {tag} <span className="ml-1 opacity-70">({count})</span>
              </Badge>
            ))}
          </div>
        </Card>
        
        {selectedTag && (
          <div className="animate-fade-in">
            <h3 className="text-xl font-medium mb-4">
              Entries with tag: <span className="text-diary-purple">{selectedTag}</span>
            </h3>
            
            <div className="space-y-4">
              {entriesWithTag.map((entry) => (
                <Card 
                  key={entry.id}
                  className="p-4 cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => navigate(`/entry/${entry.id}`)}
                >
                  <h4 className="font-medium">{entry.title}</h4>
                  <p className="text-sm text-diary-text-secondary">
                    {new Date(entry.createdAt).toLocaleDateString()}
                  </p>
                  <p className="mt-2 line-clamp-2 text-sm">
                    {entry.content}
                  </p>
                  {entry.tags.length > 0 && (
                    <div className="mt-3 flex flex-wrap gap-1">
                      {entry.tags.map(tag => (
                        <Badge 
                          key={tag} 
                          variant="secondary" 
                          className="text-xs"
                        >
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default TagsPage;
