
import React, { useMemo } from 'react';
import Layout from '@/components/Layout';
import { useDiaryStore, MoodType } from '@/store/diaryStore';
import { Card } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';
import { format, subDays } from 'date-fns';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const moodEmojis: Record<MoodType, string> = {
  happy: '😊',
  sad: '😢',
  angry: '😠',
  calm: '😌',
  excited: '😃',
  anxious: '😰',
  neutral: '😐',
};

const moodColors: Record<MoodType, string> = {
  happy: '#FFD700',     // Gold
  sad: '#6495ED',       // Cornflower Blue
  angry: '#FF6347',     // Tomato
  calm: '#98FB98',      // Pale Green
  excited: '#FF69B4',   // Hot Pink
  anxious: '#9370DB',   // Medium Purple
  neutral: '#B0C4DE',   // Light Steel Blue
};

const MoodPage: React.FC = () => {
  const navigate = useNavigate();
  const { entries } = useDiaryStore();
  
  // Get entries with mood from the last 30 days
  const recentEntries = useMemo(() => {
    const thirtyDaysAgo = subDays(new Date(), 30);
    
    return entries
      .filter(entry => entry.mood && new Date(entry.createdAt) >= thirtyDaysAgo)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }, [entries]);
  
  // Count moods for chart
  const moodCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    
    // Initialize all moods with 0
    Object.keys(moodEmojis).forEach(mood => {
      counts[mood] = 0;
    });
    
    // Count occurrences
    recentEntries.forEach(entry => {
      if (entry.mood) {
        counts[entry.mood] += 1;
      }
    });
    
    // Convert to array for chart
    return Object.entries(counts).map(([mood, count]) => ({
      mood,
      count,
    }));
  }, [recentEntries]);
  
  // Get mood distribution
  const moodDistribution = useMemo(() => {
    const totalEntries = recentEntries.length;
    if (totalEntries === 0) return [];
    
    return moodCounts.map(item => ({
      ...item,
      percentage: Math.round((item.count / totalEntries) * 100),
    }));
  }, [recentEntries, moodCounts]);
  
  // Determine predominant mood
  const predominantMood = useMemo(() => {
    if (moodCounts.length === 0) return null;
    
    const maxCount = Math.max(...moodCounts.map(item => item.count));
    return moodCounts.find(item => item.count === maxCount);
  }, [moodCounts]);
  
  return (
    <Layout>
      <div className="max-w-2xl mx-auto">
        <h2 className="text-2xl font-serif font-bold mb-6">Mood Tracker</h2>
        
        {recentEntries.length === 0 ? (
          <Card className="p-8 text-center">
            <p className="text-diary-text-secondary mb-4">
              No mood data available yet. Start adding moods to your diary entries!
            </p>
            <button 
              className="text-diary-purple hover:underline"
              onClick={() => navigate('/new-entry')}
            >
              Create your first mood entry
            </button>
          </Card>
        ) : (
          <>
            {/* Mood summary */}
            <Card className="p-6 mb-6 diary-card">
              <h3 className="text-xl font-medium mb-4">Your Mood Summary</h3>
              
              <div className="flex justify-between items-center mb-6">
                <div>
                  <p className="text-diary-text-secondary">Last 30 days</p>
                  <p className="text-2xl mt-1">
                    <span className="font-medium">{recentEntries.length}</span> entries with mood
                  </p>
                </div>
                
                {predominantMood && predominantMood.count > 0 && (
                  <div className="text-right">
                    <p className="text-diary-text-secondary">Most frequent mood</p>
                    <p className="text-2xl mt-1">
                      <span className="mr-2">{moodEmojis[predominantMood.mood as MoodType]}</span>
                      <span className="font-medium capitalize">{predominantMood.mood}</span>
                    </p>
                  </div>
                )}
              </div>
              
              {/* Mood chart */}
              <div className="h-64 mt-6">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={moodCounts} margin={{ top: 5, right: 20, bottom: 20, left: 0 }}>
                    <XAxis 
                      dataKey="mood" 
                      tickFormatter={(value) => value.charAt(0).toUpperCase() + value.slice(1)}
                    />
                    <YAxis allowDecimals={false} />
                    <Tooltip 
                      formatter={(value, name, props) => {
                        return [`${value} entries`, `${props.payload.mood}`];
                      }}
                      labelFormatter={(value) => `${value.charAt(0).toUpperCase() + value.slice(1)}`}
                    />
                    <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                      {moodCounts.map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={moodColors[entry.mood as MoodType]} 
                        />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Card>
            
            {/* Recent mood entries */}
            <Card className="p-6 diary-card">
              <h3 className="text-xl font-medium mb-4">Recent Mood Entries</h3>
              
              <div className="space-y-4">
                {recentEntries.slice(-5).reverse().map((entry) => (
                  <div 
                    key={entry.id}
                    className="p-3 border rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800"
                    onClick={() => navigate(`/entry/${entry.id}`)}
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-medium">{entry.title}</h4>
                        <p className="text-sm text-diary-text-secondary">
                          {format(new Date(entry.createdAt), 'MMM d, yyyy')}
                        </p>
                      </div>
                      
                      {entry.mood && (
                        <div 
                          className="text-2xl p-2 rounded-full"
                          style={{ backgroundColor: `${moodColors[entry.mood]}20` }}
                        >
                          {moodEmojis[entry.mood]}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                
                {recentEntries.length > 5 && (
                  <button 
                    className="w-full py-2 text-center text-diary-purple hover:underline"
                    onClick={() => {/* View all mood entries */}}
                  >
                    View all {recentEntries.length} mood entries
                  </button>
                )}
              </div>
            </Card>
          </>
        )}
      </div>
    </Layout>
  );
};

export default MoodPage;
