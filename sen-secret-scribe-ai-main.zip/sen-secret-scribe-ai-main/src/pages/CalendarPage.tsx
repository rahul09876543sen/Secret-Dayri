
import React, { useState, useMemo } from 'react';
import Layout from '@/components/Layout';
import { useDiaryStore } from '@/store/diaryStore';
import { Calendar } from '@/components/ui/calendar';
import { Card } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';

const CalendarPage: React.FC = () => {
  const navigate = useNavigate();
  const [date, setDate] = useState<Date | undefined>(new Date());
  const { entries } = useDiaryStore();
  
  // Function to get dates that have entries
  const entryDates = useMemo(() => {
    return entries.map(entry => {
      const date = new Date(entry.createdAt);
      return new Date(date.getFullYear(), date.getMonth(), date.getDate());
    });
  }, [entries]);
  
  // Get entries for selected date
  const entriesForSelectedDate = useMemo(() => {
    if (!date) return [];
    
    const selectedDateStr = format(date, 'yyyy-MM-dd');
    
    return entries
      .filter(entry => {
        const entryDate = format(new Date(entry.createdAt), 'yyyy-MM-dd');
        return entryDate === selectedDateStr;
      })
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [entries, date]);
  
  return (
    <Layout>
      <div className="max-w-2xl mx-auto">
        <h2 className="text-2xl font-serif font-bold mb-6">My Diary Calendar</h2>
        
        <Card className="p-4 mb-6 diary-card">
          <Calendar
            mode="single"
            selected={date}
            onSelect={setDate}
            className="rounded-md border"
            modifiers={{
              hasEntry: entryDates,
            }}
            modifiersStyles={{
              hasEntry: { 
                fontWeight: 'bold',
                backgroundColor: 'rgba(155, 135, 245, 0.1)',
                border: '1px solid #9b87f5' 
              }
            }}
          />
        </Card>
        
        {date && (
          <div className="animate-fade-in">
            <h3 className="text-xl font-medium mb-4">
              {format(date, 'MMMM d, yyyy')}
              <span className="text-sm text-gray-500 ml-2">
                {entriesForSelectedDate.length} {entriesForSelectedDate.length === 1 ? 'entry' : 'entries'}
              </span>
            </h3>
            
            {entriesForSelectedDate.length === 0 ? (
              <div className="text-center py-8 border border-dashed rounded-lg">
                <p className="text-diary-text-secondary">No entries for this date.</p>
                <button 
                  className="mt-2 text-diary-purple hover:underline"
                  onClick={() => navigate('/new-entry')}
                >
                  Create a new entry
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {entriesForSelectedDate.map((entry) => (
                  <Card 
                    key={entry.id}
                    className="p-4 cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => navigate(`/entry/${entry.id}`)}
                  >
                    <h4 className="font-medium">{entry.title}</h4>
                    <p className="text-sm text-diary-text-secondary">
                      {format(new Date(entry.createdAt), 'h:mm a')}
                    </p>
                    <p className="mt-2 line-clamp-2 text-sm">
                      {entry.content}
                    </p>
                    {entry.mood && (
                      <div className="mt-2 text-xs capitalize text-diary-text-secondary">
                        Mood: {entry.mood}
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default CalendarPage;
