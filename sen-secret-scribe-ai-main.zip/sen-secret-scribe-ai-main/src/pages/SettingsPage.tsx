
import React, { useState } from 'react';
import Layout from '@/components/Layout';
import { useThemeStore } from '@/store/themeStore';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { 
  Moon, 
  Sun, 
  Palette, 
  Bell, 
  Settings as SettingsIcon,
  Share,
  Info,
  CloudOff,
} from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ToggleGroup, 
  ToggleGroupItem 
} from '@/components/ui/toggle-group';

const SettingsPage: React.FC = () => {
  const { theme, setTheme } = useThemeStore();
  const [showAbout, setShowAbout] = useState(false);
  const [themeColorMode, setThemeColorMode] = useState<'light' | 'dark'>(theme);
  const [accentColor, setAccentColor] = useState('purple');
  const { toast } = useToast();
  
  const handleThemeChange = (newTheme: 'light' | 'dark') => {
    setTheme(newTheme);
    setThemeColorMode(newTheme);
    toast({
      title: `${newTheme.charAt(0).toUpperCase() + newTheme.slice(1)} theme activated`,
      description: "Your theme preference has been saved.",
    });
  };

  const accentColors = [
    { name: 'purple', color: '#9b87f5' },
    { name: 'pink', color: '#ec4899' },
    { name: 'blue', color: '#3b82f6' },
    { name: 'green', color: '#10b981' },
    { name: 'amber', color: '#f59e0b' },
  ];

  const handleAccentChange = (color: string) => {
    setAccentColor(color);
    toast({
      title: 'Accent color updated',
      description: `Your diary now has a ${color} accent color.`,
    });
  };
  
  return (
    <Layout>
      <div className="max-w-2xl mx-auto pb-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="h-10 w-1 bg-gradient-to-b from-diary-purple to-diary-dark-purple rounded-full" />
            <h2 className="text-2xl font-serif font-bold">Settings</h2>
          </div>
          
          <Tabs defaultValue="appearance" className="w-full">
            <TabsList className="grid grid-cols-3 mb-6">
              <TabsTrigger value="appearance" className="text-sm">
                <Palette className="mr-1 h-4 w-4" />
                Appearance
              </TabsTrigger>
              <TabsTrigger value="notifications" className="text-sm">
                <Bell className="mr-1 h-4 w-4" />
                Notifications
              </TabsTrigger>
              <TabsTrigger value="about" className="text-sm">
                <Info className="mr-1 h-4 w-4" />
                About
              </TabsTrigger>
            </TabsList>
            
            {/* Appearance Tab */}
            <TabsContent value="appearance">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.1, duration: 0.3 }}
              >
                <Card className="p-6 mb-6 diary-card overflow-hidden relative">
                  <div className="absolute -right-8 -top-8 w-24 h-24 rounded-full bg-diary-purple/10 blur-2xl" />
                  <div className="absolute -left-8 -bottom-8 w-16 h-16 rounded-full bg-diary-dark-purple/10 blur-xl" />
                  
                  <h3 className="text-lg font-medium mb-6">Theme Mode</h3>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.98 }}>
                      <Button
                        variant="outline"
                        size="lg"
                        className={`h-24 w-full flex flex-col items-center justify-center ${
                          theme === 'light' ? 'border-diary-purple ring-2 ring-diary-purple/20 bg-diary-purple/5' : ''
                        }`}
                        onClick={() => handleThemeChange('light')}
                      >
                        <Sun size={24} className="mb-2" />
                        <span>Light</span>
                      </Button>
                    </motion.div>
                    
                    <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.98 }}>
                      <Button
                        variant="outline"
                        size="lg"
                        className={`h-24 w-full flex flex-col items-center justify-center ${
                          theme === 'dark' ? 'border-diary-purple ring-2 ring-diary-purple/20 bg-diary-purple/5' : ''
                        }`}
                        onClick={() => handleThemeChange('dark')}
                      >
                        <Moon size={24} className="mb-2" />
                        <span>Dark</span>
                      </Button>
                    </motion.div>
                  </div>

                  <div className="mt-8">
                    <h3 className="text-lg font-medium mb-4">Accent Color</h3>
                    <p className="text-sm text-diary-text-secondary mb-4">Choose your preferred accent color for buttons and highlights.</p>
                    
                    <div className="flex justify-center">
                      <ToggleGroup type="single" value={accentColor} onValueChange={(value) => value && handleAccentChange(value)}>
                        {accentColors.map(({ name, color }) => (
                          <ToggleGroupItem key={name} value={name} aria-label={`Set ${name} theme`} className="p-0 data-[state=on]:bg-transparent">
                            <div className="p-1">
                              <div
                                className={`h-8 w-8 rounded-full transition-all ${accentColor === name ? 'ring-2 ring-offset-2' : ''}`}
                                style={{ backgroundColor: color }}
                              />
                            </div>
                          </ToggleGroupItem>
                        ))}
                      </ToggleGroup>
                    </div>
                  </div>
                </Card>
              </motion.div>
            </TabsContent>
            
            {/* Notifications Tab */}
            <TabsContent value="notifications">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.1, duration: 0.3 }}
              >
                <Card className="p-6 mb-6 diary-card">
                  <h3 className="text-lg font-medium mb-6">Notifications</h3>
                  
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Daily Reminder</h4>
                        <p className="text-sm text-diary-text-secondary">Remind me to write in my diary</p>
                      </div>
                      <Switch id="daily-reminder" />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Weekly Insights</h4>
                        <p className="text-sm text-diary-text-secondary">Receive mood and writing insights</p>
                      </div>
                      <Switch id="weekly-insights" />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Memory Flashbacks</h4>
                        <p className="text-sm text-diary-text-secondary">Memories from past entries</p>
                      </div>
                      <Switch id="memory-flashbacks" defaultChecked />
                    </div>
                  </div>
                </Card>
                
                <Card className="p-6 diary-card">
                  <h3 className="text-lg font-medium mb-6">Privacy</h3>
                  
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Cloud Backup</h4>
                        <p className="text-sm text-diary-text-secondary">Automatically backup your entries</p>
                      </div>
                      <Switch id="cloud-backup" />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Biometric Lock</h4>
                        <p className="text-sm text-diary-text-secondary">Use fingerprint to unlock app</p>
                      </div>
                      <Switch id="biometric-lock" />
                    </div>
                    
                    <div className="mt-4">
                      <Button variant="outline" className="w-full">
                        <CloudOff size={18} className="mr-2" />
                        Clear All Cached Data
                      </Button>
                    </div>
                  </div>
                </Card>
              </motion.div>
            </TabsContent>
            
            {/* About Tab */}
            <TabsContent value="about">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.1, duration: 0.3 }}
              >
                <Card className="p-6 mb-6 diary-card overflow-hidden relative">
                  <div className="absolute -right-8 -top-8 w-24 h-24 rounded-full bg-diary-purple/10 blur-2xl" />
                  <h3 className="text-lg font-medium mb-4">About</h3>
                  
                  <div className="flex flex-col items-center space-y-4 mb-6">
                    <div className="w-16 h-16 rounded-xl bg-diary-purple/20 flex items-center justify-center">
                      <SettingsIcon size={32} className="text-diary-purple" />
                    </div>
                    <h4 className="text-xl font-serif">Sen Secret Diary</h4>
                    <p className="text-sm text-diary-text-secondary">Version 1.0</p>
                  </div>
                  
                  <p className="text-sm text-center mb-6">
                    Your personal space to capture thoughts, track moods, and reflect on your daily experiences.
                  </p>
                  
                  <div className="flex justify-center space-x-3">
                    <Button variant="outline" size="sm" onClick={() => setShowAbout(true)}>
                      <Info size={16} className="mr-1" />
                      Learn More
                    </Button>
                    <Button variant="outline" size="sm">
                      <Share size={16} className="mr-1" />
                      Share App
                    </Button>
                  </div>
                </Card>
                
                <Card className="p-6 diary-card">
                  <h3 className="text-lg font-medium mb-4">Support</h3>
                  
                  <div className="space-y-3">
                    <Button variant="ghost" className="w-full justify-start">
                      Rate this app
                    </Button>
                    <Button variant="ghost" className="w-full justify-start">
                      Send feedback
                    </Button>
                    <Button variant="ghost" className="w-full justify-start">
                      Terms of service
                    </Button>
                    <Button variant="ghost" className="w-full justify-start">
                      Privacy policy
                    </Button>
                  </div>
                </Card>
              </motion.div>
            </TabsContent>
          </Tabs>
        </motion.div>
        
        <Dialog open={showAbout} onOpenChange={setShowAbout}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>About Sen Secret Diary</DialogTitle>
            </DialogHeader>
            <DialogDescription>
              <div className="space-y-4">
                <p>
                  Sen Secret Diary is a private journaling app designed to help you capture your thoughts, track your moods, and reflect on your experiences.
                </p>
                
                <p>
                  This app was created to provide a beautiful, secure place for your personal reflections. All your diary entries are stored locally on your device.
                </p>
                
                <div className="pt-4 border-t">
                  <p className="text-sm">
                    Version 1.0 - Created with ❤️
                  </p>
                </div>
              </div>
            </DialogDescription>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
};

export default SettingsPage;
