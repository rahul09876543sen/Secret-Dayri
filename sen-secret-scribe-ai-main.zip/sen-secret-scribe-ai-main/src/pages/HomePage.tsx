
import React from 'react';
import { useDiaryStore, DiaryEntry } from '@/store/diaryStore';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import { Smile, Tag } from 'lucide-react';

const EntryCard: React.FC<{ entry: DiaryEntry }> = ({ entry }) => {
  const navigate = useNavigate();
  const formattedDate = format(new Date(entry.createdAt), 'MMMM d, yyyy');

  // Truncate content for preview
  const previewContent = entry.content.length > 150 
    ? entry.content.substring(0, 150) + '...'
    : entry.content;
    
  return (
    <Card 
      className="diary-card mb-4 bg-white dark:bg-gray-800 cursor-pointer animate-fade-in opacity-0" 
      style={{ animationDelay: '100ms' }}
      onClick={() => navigate(`/entry/${entry.id}`)}
    >
      <CardHeader className="pb-2">
        <CardTitle className="text-xl">{entry.title}</CardTitle>
        <p className="text-sm text-diary-text-secondary">{formattedDate}</p>
      </CardHeader>
      <CardContent>
        <p className="diary-entry text-base mb-3">{previewContent}</p>
        
        {/* Mood and tags display */}
        <div className="flex justify-between items-center mt-2">
          {entry.mood && (
            <div className="flex items-center text-sm text-diary-text-secondary">
              <Smile size={16} className="mr-1" />
              <span className="capitalize">{entry.mood}</span>
            </div>
          )}
          
          {entry.tags.length > 0 && (
            <div className="flex items-center text-sm text-diary-text-secondary">
              <Tag size={16} className="mr-1" />
              <span>{entry.tags.slice(0, 2).join(', ')}{entry.tags.length > 2 ? '...' : ''}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

const HomePage: React.FC = () => {
  const { entries } = useDiaryStore();
  
  // Sort entries by date (newest first)
  const sortedEntries = [...entries].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  return (
    <Layout>
      <div className="max-w-2xl mx-auto">
        <h2 className="text-2xl font-serif font-bold mb-6 animate-fade-in">My Diary Entries</h2>
        
        {sortedEntries.length === 0 ? (
          <div className="text-center py-10 animate-fade-in opacity-0" style={{ animationDelay: '200ms' }}>
            <p className="text-diary-text-secondary text-lg">No entries yet. Start writing your diary!</p>
          </div>
        ) : (
          sortedEntries.map((entry) => (
            <EntryCard key={entry.id} entry={entry} />
          ))
        )}
      </div>
    </Layout>
  );
};

export default HomePage;
