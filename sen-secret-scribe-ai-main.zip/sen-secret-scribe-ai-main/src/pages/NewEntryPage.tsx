
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDiaryStore, MoodType } from '@/store/diaryStore';
import Layout from '@/components/Layout';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Smile } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const moodOptions: { value: MoodType; label: string }[] = [
  { value: 'happy', label: 'Happy 😊' },
  { value: 'sad', label: 'Sad 😢' },
  { value: 'angry', label: 'Angry 😠' },
  { value: 'calm', label: 'Calm 😌' },
  { value: 'excited', label: 'Excited 😃' },
  { value: 'anxious', label: 'Anxious 😰' },
  { value: 'neutral', label: 'Neutral 😐' },
];

// AI writing prompts
const writingPrompts = [
  "What made you smile today?",
  "What's something new you learned recently?",
  "Describe a moment that challenged you today.",
  "Write about someone who made a difference in your life.",
  "What are you grateful for today?",
  "If you could change one thing about today, what would it be?",
  "What are you looking forward to tomorrow?",
  "Describe your current mood using metaphors.",
  "What was the most peaceful moment of your day?",
  "Write about a conversation that impacted you recently."
];

const NewEntryPage: React.FC = () => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [mood, setMood] = useState<MoodType | undefined>(undefined);
  const [tags, setTags] = useState('');
  const { addEntry } = useDiaryStore();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim() || !content.trim()) {
      toast({
        title: "Missing information",
        description: "Please add a title and content for your diary entry.",
        variant: "destructive",
      });
      return;
    }

    addEntry({
      title,
      content,
      mood,
      tags: tags.split(',').map(tag => tag.trim()).filter(Boolean),
      images: [],
    });
    
    toast({
      title: "Entry saved",
      description: "Your diary entry has been saved successfully.",
    });
    
    navigate('/');
  };

  // Get a random writing prompt
  const getRandomPrompt = () => {
    const randomIndex = Math.floor(Math.random() * writingPrompts.length);
    setContent(content => content + (content ? '\n\n' : '') + writingPrompts[randomIndex]);
  };

  return (
    <Layout showFAB={false}>
      <div className="max-w-2xl mx-auto">
        <h2 className="text-2xl font-serif font-bold mb-6">New Diary Entry</h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="title" className="block mb-2 font-medium">
              Title
            </label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Today's thoughts..."
              className="diary-input"
              required
            />
          </div>
          
          <div>
            <div className="flex justify-between mb-2">
              <label htmlFor="content" className="block font-medium">
                What's on your mind?
              </label>
              <Button 
                type="button" 
                variant="outline" 
                size="sm"
                onClick={getRandomPrompt}
                className="text-xs"
              >
                Need inspiration?
              </Button>
            </div>
            
            <Textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Write your thoughts here..."
              className="diary-input min-h-[200px]"
              required
            />
          </div>
          
          <div>
            <label className="block mb-2 font-medium">
              How are you feeling?
            </label>
            
            <div className="flex flex-wrap gap-2">
              {moodOptions.map((option) => (
                <Button
                  key={option.value}
                  type="button"
                  variant={mood === option.value ? "default" : "outline"}
                  size="sm"
                  className={mood === option.value ? "bg-diary-purple" : ""}
                  onClick={() => setMood(option.value)}
                >
                  {option.label}
                </Button>
              ))}
            </div>
          </div>
          
          <div>
            <label htmlFor="tags" className="block mb-2 font-medium">
              Tags (comma separated)
            </label>
            <Input
              id="tags"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="personal, reflection, goals"
              className="diary-input"
            />
          </div>
          
          <div className="flex justify-end space-x-4 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate(-1)}
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              className="bg-diary-purple hover:bg-diary-dark-purple"
            >
              Save Entry
            </Button>
          </div>
        </form>
      </div>
    </Layout>
  );
};

export default NewEntryPage;
