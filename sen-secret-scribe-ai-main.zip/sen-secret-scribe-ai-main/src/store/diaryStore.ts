
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type MoodType = 'happy' | 'sad' | 'angry' | 'calm' | 'excited' | 'anxious' | 'neutral';

export interface DiaryEntry {
  id: string;
  title: string;
  content: string;
  createdAt: string;
  mood?: MoodType;
  tags: string[];
  images?: string[];
}

interface DiaryStore {
  entries: DiaryEntry[];
  addEntry: (entry: Omit<DiaryEntry, 'id' | 'createdAt'>) => void;
  updateEntry: (id: string, entry: Partial<DiaryEntry>) => void;
  deleteEntry: (id: string) => void;
  getEntry: (id: string) => DiaryEntry | undefined;
  getEntriesByDate: (date: string) => DiaryEntry[];
  getEntriesByMood: (mood: MoodType) => DiaryEntry[];
  getEntriesByTag: (tag: string) => DiaryEntry[];
}

export const useDiaryStore = create<DiaryStore>()(
  persist(
    (set, get) => ({
      entries: [],
      addEntry: (entry) => {
        const newEntry: DiaryEntry = {
          ...entry,
          id: Date.now().toString(),
          createdAt: new Date().toISOString(),
        };
        set((state) => ({ entries: [...state.entries, newEntry] }));
      },
      updateEntry: (id, updatedEntry) => {
        set((state) => ({
          entries: state.entries.map((entry) => 
            entry.id === id ? { ...entry, ...updatedEntry } : entry
          )
        }));
      },
      deleteEntry: (id) => {
        set((state) => ({
          entries: state.entries.filter((entry) => entry.id !== id),
        }));
      },
      getEntry: (id) => {
        return get().entries.find((entry) => entry.id === id);
      },
      getEntriesByDate: (date) => {
        return get().entries.filter((entry) => {
          const entryDate = new Date(entry.createdAt).toISOString().split('T')[0];
          return entryDate === date;
        });
      },
      getEntriesByMood: (mood) => {
        return get().entries.filter((entry) => entry.mood === mood);
      },
      getEntriesByTag: (tag) => {
        return get().entries.filter((entry) => entry.tags.includes(tag));
      },
    }),
    {
      name: 'sen-secret-diary',
    }
  )
);
